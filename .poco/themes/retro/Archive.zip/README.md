---
header: "header.md"
nav: "nav.md"
aside: "aside.md"
footer: "footer.md"
stylesheets:
- "https://cdn.jsdelivr.net/gh/markdowncss/retro@3171af759c8cf61b990c65846d35a0dfb4031824/css/retro.css"
styles:
- "aside{width:20%}"
- "article{width:80%}" 
---
The retro theme is based on [retro](https://github.com/markdowncss/retro) 
stylesheet by [John Otander](https://johno.com/).


